function varargout = grafsincs(x)

if nargin < 1
    error('grafsincs:nargin', 'Reikia pateikti vektoriu-eilute x.');
end
if nargin > 1
    error('grafsincs:nargin', 'Per daug iejimo kintamuju: reikia tik vieno (x).');
end

if ~isnumeric(x) || ~isrow(x)
    error('grafsincs:tipas', 'x turi buti skaiciu vektorius-eilute.');
end

if nargout > 2
    error('grafsincs:nargout', 'Per daug isejimo kintamuju: daugiausia 2 (sin, cos).');
end

s = sin(x);
c = cos(x);

if nargout == 0
   
    plot(x, s, 'b-', x, c, 'r--');
    grid on;
    xlabel('x'); ylabel('y');
    legend('sin(x)', 'cos(x)');
    title('sin(x) ir cos(x) grafikai');
else
    varargout{1} = s;
    if nargout >= 2
        varargout{2} = c;
    end
end
end
