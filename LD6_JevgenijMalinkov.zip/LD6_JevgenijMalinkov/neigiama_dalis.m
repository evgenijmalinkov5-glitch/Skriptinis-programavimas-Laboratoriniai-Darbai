function neigiama_dalis

global x y
k = (x < 0);
y(k) = -sin(x(k));
end
