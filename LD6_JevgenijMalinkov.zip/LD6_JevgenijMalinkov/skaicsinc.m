function y = skaicsinc(x)

y = ones(size(x));         
nz = (x ~= 0);            
y(nz) = sin(x(nz)) ./ x(nz);
end
