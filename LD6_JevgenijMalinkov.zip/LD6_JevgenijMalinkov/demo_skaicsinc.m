% 6 Laboratorinis darbas
% 2026-10-19
% MATLAB kintamieji,skriptai, funkcijos
% 27 variantas
%EIf-25 Jevgenij Malinkov
% Pirmos uzduoties demonstracija
help skaicsinc
skaicsinc(0)
skaicsinc(pi/2)
skaicsinc([-4 0 1])
%%
% Antra uzduotis
clear
close all
global x y

x = 2*pi : -0.1 : -2*pi;   
y = zeros(size(x));
neigiama_dalis;            
neneigiama_dalis;          

plot(x, y, 'k-.+');          
grid on; xlabel('x'); ylabel('y');
title('y(x) = -sin(x), kai x<0; sin(x), kai x>=0');
%%
%Papildoma uzduotis 
%16 variantas
clear
close all

help grafsincs

x = 0:0.1:2*pi;

disp('1) Be isejimo kintamuju - braizo grafikus:');
grafsincs(x)

disp('2) Vienas isejimo kintamasis - grazina sin:');
s = grafsincs(x);
disp(s(1:5))

disp('3) Du isejimo kintamieji - grazina sin ir cos:');
[s, c] = grafsincs(x);
disp([s(1:5); c(1:5)])

disp('4) Klaidos atvejai:');
try, grafsincs();              catch e, disp(e.message); end
try, grafsincs(x');            catch e, disp(e.message); end
try, [a,b,d] = grafsincs(x);   catch e, disp(e.message); end
